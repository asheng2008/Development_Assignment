package process;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.JOptionPane;

/** 
 * The DataTransformer class is used for converting data into different data structure
 */

public class DataTransformer {

	/**
	* This method is used for sorting Map keys according based on the values
	* @param map Map object that need to be sorted
	* @return Map a sorted Map object to be returned after sorting
	*/
	public static Map sortMapByValue(Map map){
		class ValueComparator implements Comparator {
			Map map;

			public ValueComparator(Map map) {
				this.map = map;
			}

			public int compare(Object keyA, Object keyB) {
				Comparable valueA = (Comparable) map.get(keyA);
				Comparable valueB = (Comparable) map.get(keyB);
				int res= valueB.compareTo(valueA);
				return res != 0 ? res : 1;
			}
		}
		Map<String, Integer> newMap = new TreeMap(new ValueComparator(map));
		newMap.putAll(map);
		return newMap;
	}
	
	/**
	* This method is used for converting Map object to String format
	* @param map Map object that needs to be converted into String object
	* @return String Map elements converted into String
	*/

	public static String transformMaptoString(Map<String,Integer> sortedMap)
	{
		StringBuilder strBuilder = new StringBuilder();

		Set set = sortedMap.entrySet();
        Iterator iterator = set.iterator();
        while(iterator.hasNext()) {
              Map.Entry me = (Map.Entry)iterator.next();
              strBuilder.append(me.getKey()+" "+me.getValue());
              strBuilder.append(System.getProperty("line.separator"));
        }

		return strBuilder.toString();
	}
	
	/**
	* This method is used for transforming List object to Map object
	* @param listLines List of String formated lines 
	* @param delimiter It separates the key and values in the line
	* @return Map<String,Integer> Map object to be returned after conversion
	*/
	public static Map<String,Integer> transformListIntoMap(List<String> listLines,String delimiter) 
	{
		
		if(null==listLines || listLines.isEmpty())
		{
			throw new NullPointerException("The given list object is empty");
		}
		Map<String,Integer> mapData = new HashMap<String,Integer>();
		for(String line:listLines)
		{
			String[] splitData = line.split(delimiter);
			mapData.put(splitData[0], Integer.parseInt(splitData[1]));
		}
		return mapData;
	}

}


