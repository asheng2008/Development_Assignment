package process;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import fileHandle.FileHandler;

/** 
 * The InventoryProcessor class processes the data 
 * by calling different functions of various classes
 */
public class InventoryProcessor {
	
	private String strInputFilePath;
	private String strOutputFilePath;

	public void setStrInputFilePath(String strInputFilePath) {
		this.strInputFilePath = strInputFilePath;
	}

	public void setStrOutputFilePath(String strOutputFilePath) {
		this.strOutputFilePath = strOutputFilePath;
	}
	
	/**
	* This method is used for processing the input file content 
	* and writing the processed content back to the output file
	* @return nothing
	*/

	public void process() throws IOException,NullPointerException
	{
		if(null==strInputFilePath || 0==strInputFilePath.length() || 0==strOutputFilePath.length() || null==strOutputFilePath)
		{
			throw new NullPointerException("Input or Output file path is empty");
		}
		List<String> lines= FileHandler.readFileDataAsList(strInputFilePath);
		Map<String,Integer> map = DataTransformer.transformListIntoMap(lines, " ");
		map = DataTransformer.sortMapByValue(map);
		FileHandler.writeFile(strOutputFilePath, DataTransformer.transformMaptoString(map));
		JOptionPane.showMessageDialog(null, "Sorted input file content and written the processed elements in outputfile");
	}
	
	
	
	

}
