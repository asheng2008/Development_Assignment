package gui;

/** 
 * The AppLauncher class launches the application that
 * simply allows an user to enter or select file paths and
 * process the files
 */
public class AppLauncher {
	
	public static void main(String[] args) {
		
		//Launching the application by calling launch method on object of MainWindow class
		new MainWindow().launch();
	}

}
