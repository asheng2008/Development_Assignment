package gui;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.AccessDeniedException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import process.InventoryProcessor;

/** 
 * The MainWindow class create a Window with some interactive components
 * that allows users to enter or select Input file path whih contains data to be processed and
 * output file path where the processed data will be copied into.
 */
public class MainWindow extends JFrame{

	private JLabel lblInputFileTxtField, lblOutputFileTxtField;
	private JButton btnProcess,btnBrowseInputFileChooser,btnBrowseOutputFileChooser;
	private JTextField editInputFileTxtField, editOutputFileTxtField;
	private JFileChooser inputFileChooser;
	private InventoryProcessor processor;
	
	private class CustomActionListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent ae) {

			if(ae.getSource()==btnProcess)
			{
				setFileParameter(editInputFileTxtField.getText(),editOutputFileTxtField.getText());
				try
				{
					processor.process();
				}
				catch(AccessDeniedException ade) {
					JOptionPane.showMessageDialog(null, "The given input or output file does not exist");
				}
				catch(NullPointerException npe)
				{
					JOptionPane.showMessageDialog(null, "The given input or output file path is empty");
				}
				catch(IOException ioe)
				{
					JOptionPane.showMessageDialog(null, ioe.toString());
				}
			}
			else if(ae.getSource()==btnBrowseInputFileChooser)
			{

				int returnVal = inputFileChooser.showOpenDialog(null);
				if(returnVal==JFileChooser.APPROVE_OPTION)
				{
					File selectedFile = inputFileChooser.getSelectedFile();
					editInputFileTxtField.setText(selectedFile.getAbsolutePath());
				}
				setFileParameter(editInputFileTxtField.getText(),editOutputFileTxtField.getText());

			}
			else if(ae.getSource()==btnBrowseOutputFileChooser)
			{
				int returnVal = inputFileChooser.showOpenDialog(null);
				if(returnVal==JFileChooser.APPROVE_OPTION)
				{
					File selectedFile = inputFileChooser.getSelectedFile();
					editOutputFileTxtField.setText(selectedFile.getAbsolutePath());
				}
				setFileParameter(editInputFileTxtField.getText(),editOutputFileTxtField.getText());
			}
			

		}

	}

	public MainWindow()
	{
		initUI();
	}
	
	/**
	* The method initialize basic UI Window with some of the 
	* settings enabled
	*/
	private void initUI()
	{
		setTitle("Inventory Processor");
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(screenSize.width/4, screenSize.height/5); 
		setLocationRelativeTo(null);
		add(initComponent());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
	}

	/**
	* This method is used for intializing UI Components of the Window
	* @return JPanel it is object of the JPanel which would contain UI components
	*/
	private JPanel initComponent()
	{
		JPanel panel = new JPanel();
		panel.setLayout(null);

		lblInputFileTxtField = new JLabel("Input File Path");
		lblInputFileTxtField.setBounds(10, 10, 80, 25);
		panel.add(lblInputFileTxtField);

		editInputFileTxtField = new JTextField(20);
		editInputFileTxtField.setBounds(100, 10, 160, 25);
		panel.add(editInputFileTxtField);

		btnBrowseInputFileChooser = new JButton("Browse..");
		btnBrowseInputFileChooser.setBounds(280, 10, 80, 25);
		btnBrowseInputFileChooser.addActionListener(new CustomActionListener());
		panel.add(btnBrowseInputFileChooser);

		lblOutputFileTxtField = new JLabel("Output File Path");
		lblOutputFileTxtField.setBounds(10, 40, 80, 25);
		panel.add(lblOutputFileTxtField);

		editOutputFileTxtField = new JTextField(20);
		editOutputFileTxtField.setBounds(100, 40, 160, 25);
		panel.add(editOutputFileTxtField);

		btnBrowseOutputFileChooser = new JButton("Browse..");
		btnBrowseOutputFileChooser.setBounds(280, 40, 80, 25);
		btnBrowseOutputFileChooser.addActionListener(new CustomActionListener());
		panel.add(btnBrowseOutputFileChooser);

		btnProcess = new JButton("Process");
		btnProcess.setBounds(10, 80, 120, 25);
		btnProcess.addActionListener(new CustomActionListener());
		panel.add(btnProcess);

		inputFileChooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		inputFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"txt","txt");
		inputFileChooser.setFileFilter(filter);

		processor = new InventoryProcessor();

		return panel;
	}

	/**
	* This method is used for assigning file paths to InventoryProcessor class fields
	* @return Nothing
	* @param inputFilePath It is the path of Input file
	* @param outputFilePath It is the path of output file
	*/
	private void setFileParameter(String inputFilePath,String outputFilePath)
	{
		processor.setStrInputFilePath(inputFilePath);
		processor.setStrOutputFilePath(outputFilePath);
	}
	/**
	* This method is used for making the Window visible
	* @return Nothing
	*/
	public void launch()
	{
		setVisible(true);
	}

}
