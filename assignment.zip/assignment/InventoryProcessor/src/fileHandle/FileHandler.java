package fileHandle;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

/** 
 * The FileHandler class is responsible for reading and writing text files
 * It contains some static methods which can be called for file operation.
 */
public class FileHandler {

	/**
	* This method is used for reading a file
	* @param inputFilePath It is the file path
	* @return List<String> List of lines read from the file
	*/
	public static List<String> readFileDataAsList(String inputFilePath) throws IOException
	{
		List<String> lines = Collections.emptyList();
		lines =	Files.readAllLines(Paths.get(inputFilePath), StandardCharsets.UTF_8);
		return lines;
	}
	
	/**
	* This method is used for writing a file with the given string
	* @param outputFilePath It is the file path to be written
	* @param strData It is the Data to write into the file
	* @return nothing
	*/
	
	public static void writeFile(String outputFilePath, String strData) throws IOException
	{
		Path path = Paths.get(outputFilePath);
		BufferedWriter writer = Files.newBufferedWriter(path, Charset.forName("UTF-8"));
		writer.write(strData);
		writer.flush();
		writer.close();
	}
}
