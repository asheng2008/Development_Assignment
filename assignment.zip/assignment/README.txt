What Is This?
-------------
This application is intended to sort the key-value paired content of a file 
and write another file with sorted content.

Pre-requisite to run the application

1. Have JDK 8.0 installed on the system and set jre path to Environment variable PATH

Optional requirements:-

1. Eclipse IDE (Any version)

How To Use The Application
-----------------------

There are two ways to run the application:

1. Please launch the application by duble-clicking the InventoryProcessor.jar file.
A window will pop up with some UI components for user input e.g. Input FIle Path, Output File path
and after providing file paths, please click on Process button. You can now open output file for result

2. Please import the given Eclipse project into Eclipse workspace and go to package gui
and run the class AppLauncher as java application. A window will pop up with some UI components 
for user input e.g. Input FIle Path, Output File path and after providing file paths, 
please click on Process button. You can now open output file for result.


	